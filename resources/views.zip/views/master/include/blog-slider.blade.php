 <section>
      <div class="container">
        <div class="owl-carousel owl-theme blog-slider">
          <div class="card blog__slide text-center">
            <div class="blog__slide__img">
              <img class="card-img rounded-0" src="{{asset('template/img/blog/blog-slider/blog-slide1.png')}}" alt="">
            </div>
            <div class="blog__slide__content">
              <a class="blog__slide__label" href="#">Fashion</a>
              <h3><a href="#">New york fashion week's continued the evolution</a></h3>
              <p>2 days ago</p>
            </div>
          </div>
          <div class="card blog__slide text-center">
            <div class="blog__slide__img">
              <img class="card-img rounded-0" src="{{asset('template/img/blog/blog-slider/blog-slide2.png')}}" alt="">
            </div>
            <div class="blog__slide__content">
              <a class="blog__slide__label" href="#">Fashion</a>
              <h3><a href="#">New york fashion week's continued the evolution</a></h3>
              <p>2 days ago</p>
            </div>
          </div>
          <div class="card blog__slide text-center">
            <div class="blog__slide__img">
              <img class="card-img rounded-0" src="{{asset('template/img/blog/blog-slider/blog-slide3.png')}}" alt="">
            </div>
            <div class="blog__slide__content">
              <a class="blog__slide__label" href="#">Fashion</a>
              <h3><a href="#">New york fashion week's continued the evolution</a></h3>
              <p>2 days ago</p>
            </div>
          </div>
          <div class="card blog__slide text-center">
            <div class="blog__slide__img">
              <img class="card-img rounded-0" src="{{asset('template/img/blog/blog-slider/blog-slide1.png')}}" alt="">
            </div>
            <div class="blog__slide__content">
              <a class="blog__slide__label" href="#">Fashion</a>
              <h3><a href="#">New york fashion week's continued the evolution</a></h3>
              <p>2 days ago</p>
            </div>
          </div>
          <div class="card blog__slide text-center">
            <div class="blog__slide__img">
              <img class="card-img rounded-0" src="{{asset('template/img/blog/blog-slider/blog-slide2.png')}}" alt="">
            </div>
            <div class="blog__slide__content">
              <a class="blog__slide__label" href="#">Fashion</a>
              <h3><a href="#">New york fashion week's continued the evolution</a></h3>
              <p>2 days ago</p>
            </div>
          </div>
          <div class="card blog__slide text-center">
            <div class="blog__slide__img">
              <img class="card-img rounded-0" src="{{asset('template/img/blog/blog-slider/blog-slide3.png')}}" alt="">
            </div>
            <div class="blog__slide__content">
              <a class="blog__slide__label" href="#">Fashion</a>
              <h3><a href="#">New york fashion week's continued the evolution</a></h3>
              <p>2 days ago</p>
            </div>
          </div>
        </div>
      </div>
    </section>
