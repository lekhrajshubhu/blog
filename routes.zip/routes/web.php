<?php

Route::get('/', function () {
    return view('master.layout');
});
