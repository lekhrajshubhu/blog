<?php
//default home page
Route::get('/index', 'HomeController@index');
