<?php

//service page route
Route::get('/service', 'ServiceController@index');
