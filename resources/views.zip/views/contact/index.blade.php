@extends('master.layout')





@section('title')
    Contact
@endsection
@section("main-body")



@include('contact.include.banner')
  </main>



@endsection
