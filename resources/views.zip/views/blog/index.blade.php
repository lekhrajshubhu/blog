@extends('master.layout')


@section('title')
    Blog
@endsection
@section('main-body')

thi is blog

@endsection
