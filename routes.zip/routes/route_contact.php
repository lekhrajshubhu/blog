<?php
//contact page route
Route::get('/contact', 'ContactController@index');
