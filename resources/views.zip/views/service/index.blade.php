@extends('master.layout')


@section('title')
    Service
@endsection


@section("main-section")

<div>
	<p>
		this is service page
	</p>
</div>



@endsection
