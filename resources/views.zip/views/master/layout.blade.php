
@include('master.include.head')



  <!--================Header Menu Area =================-->
@include('master.include.header-nav')


  <!--================Header Menu Area =================-->



@yield("main-body")


<!-- ============ footer script ========== --->
@include('master.include.footer-script')
