<?php
//blog page route
Route::get('/blog', 'BlogController@index');
